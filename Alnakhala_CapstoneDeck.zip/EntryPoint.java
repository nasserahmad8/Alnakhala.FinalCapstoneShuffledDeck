package DeckOfCards;

public class EntryPoint {
    public static void main(String[] args) {
        Alnakhala_CapstoneDeck deckProgram = new Alnakhala_CapstoneDeck();
    }
}
