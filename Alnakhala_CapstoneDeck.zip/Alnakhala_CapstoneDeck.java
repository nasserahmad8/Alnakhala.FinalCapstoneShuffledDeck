package DeckOfCards;

public class Alnakhala_CapstoneDeck {
    
    public static void main(String[] args) {
        new Alnakhala_CapstoneDeck();
    }
    
    public Alnakhala_CapstoneDeck() { // constructor
        // Call the method to create the deck
        createDeck();
    }
    
    public void createDeck() {
        // Initialize the ranks and the suits
        String[] suits = new String[]{ "clubs", "diamonds", "hearts", "spades" };
        String[] ranks = new String[]{ "ace", "2", "3", "4", "5", "6", "7", "8", "9", "10",
                         "jack", "queen", "king" };
                          
        // Create the cards array
        String[] cards = createArrayForCards(ranks.length, suits.length);
        
        // Add rank to each card
        cards = addRankToEachCard(cards, ranks);
        
        // Add suit to each card
        cards = addSuitToEachCard(cards, suits, ranks);
        
        // Display the deck
        displayDeckOfCards(cards);
    }
    
    public String[] addSuitToEachCard(String[] cards, String[] suits, String[] ranks) {
        for (int n = 0; n < cards.length; n++) {
            int suitIndex = n / ranks.length;
            cards[n] = cards[n] + " of " + suits[suitIndex];
        }
        return cards;
    }
    
    public String[] addRankToEachCard(String[] cards, String[] ranks) {
        for (int n = 0; n < cards.length; n++) {
            int rankIndex = n % ranks.length;
            cards[n] = ranks[rankIndex];
        }
        return cards;
    }
    
    public String[] createArrayForCards(int rankLength, int suitLength) {
        // Make the cards array exactly the right size for all the cards 
        return new String[rankLength * suitLength];
    }
    
    public void displayDeckOfCards(String[] cards) {
        System.out.println("Deck of Cards:");
        for (int n = 0; n < cards.length; n++) {
            System.out.println(n + ": " + cards[n]);
        }
        System.out.println();
    }
}