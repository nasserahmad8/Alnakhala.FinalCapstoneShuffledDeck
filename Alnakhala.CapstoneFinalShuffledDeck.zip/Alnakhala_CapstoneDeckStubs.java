public class Alnakhala_CapstoneDeckStubs {
    public static void main(String[] args) {
        // Will create and display deck
    }
    
    public Alnakhala_CapstoneDeckStubs() {
        
    }
    
    public void createDeck() {
        // Will create all 52 cards
    }
    
    public void displayDeck() {
        // Will display all cards in the deck
    }
    
    public String rank() {
        // Will return a rank
    }
    
    public String suit() {
        // Will return a suit
    }
}

class Card {
    public String rank;
    public String suit;
    
    public Card(String rank, String suit) {
        
    }
}

class Deck {
    private Card[] cards;
    
    public Deck() {
        
    }
    
    public void buildDeck() {
        // Will build all 52 cards
    }
    
    public Card[] cards() {
        // Will return the array of cards
    }
}