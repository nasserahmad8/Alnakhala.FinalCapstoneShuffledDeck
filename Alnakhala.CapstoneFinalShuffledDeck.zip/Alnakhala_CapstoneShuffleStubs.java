public class Alnakhala_CapstoneShuffleStubs {
    public static void main(String[] args) {
        new Alnakhala_CapstoneShuffleStubs();
    }

   
    public void DeckThatIsShuffled() { // constructor
        // initialize the ranks and the suits
        // suits = { "clubs", "diamonds", "hearts", "spades" };
        // ranks = { "ace", "2", "3", "4", "5", "6", "7", "8", "9", "10",
           //               "jack", "queen", "king" };
                          
        // create the cards array
        
        // make the cards array exactly the right size for all the cards
        
        // add rank to each card
        
        // add suit to each card
    }
    
    public String[] addSuitToEachCard(String[] cards, String[] suits) {

    }
    
    public String[] addRankToEachCard(String[] cards, String[] ranks) {
    }
    
    public String[] createArrayForCards(int rankLength, int suitLength) {
        // make the cards array exactly the right size for all the cards 
        
    }
    
    public void displayDeckOfCards(String[] cards) {
    }
    
    // Adding the shuffle stub methods
    public void shuffleDeck(String[] cards) {
        // code to shuffle the deck
        // Select the card at that random position from the original deck
        // Mark that position as used (-1) to avoid selecting it again
        // If the number is already chosen find the next available position
    }
    
    public void displayShuffledDeck(String[] shuffledCards) {
        // code to display the shuffled deck
    }
}