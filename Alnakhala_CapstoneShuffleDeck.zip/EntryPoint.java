package ShuffledDeck;

public class EntryPoint {
    public static void main(String[] args) {
        Alnakhala_CapstoneShuffleDeck deckProgram = new Alnakhala_CapstoneShuffleDeck();
        deckProgram.createAndShuffleDeck();
    }
}