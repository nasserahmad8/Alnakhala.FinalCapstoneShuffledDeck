package ShuffledDeck;

public class Alnakhala_CapstoneShuffleDeck {
    
    public static void main(String[] args) {
        new Alnakhala_CapstoneShuffleDeck();
    }

    public void createAndShuffleDeck() { // constructor
        // initialize the ranks and the suits
        String[] suits = new String[]{ "clubs", "diamonds", "hearts", "spades" };
        String[] ranks = new String[]{ "ace", "2", "3", "4", "5", "6", "7", "8", "9", "10",
                         "jack", "queen", "king" };
                          
        // create the cards array
        String[] cards = createArrayForCards(ranks.length, suits.length);
        
        // add rank to each card
        cards = addRankToEachCard(cards, ranks);
        
        // add suit to each card
        cards = addSuitToEachCard(cards, suits);
        
        // display the original deck
        displayDeckOfCards(cards);
        
        // shuffle the deck
        String[] shuffledDeck = shuffleDeck(cards);
        
        // display the shuffled deck
        displayShuffledDeck(shuffledDeck);
    }
    
    public String[] addSuitToEachCard(String[] cards, String[] suits) {
        String[] ranks = new String[]{ "ace", "2", "3", "4", "5", "6", "7", "8", "9", "10",
                         "jack", "queen", "king" };
                         
        for (int n = 0; n < cards.length; n++) {
            int suitIndex = n / ranks.length;
            cards[n] = cards[n] + " of " + suits[suitIndex];
        }
        return cards;
    }
    
    public String[] addRankToEachCard(String[] cards, String[] ranks) {
        for (int n = 0; n < cards.length; n++) {
            int rankIndex = n % ranks.length;
            cards[n] = ranks[rankIndex];
        }
        return cards;
    }
    
    public String[] createArrayForCards(int rankLength, int suitLength) {
        // make the cards array exactly the right size for all the cards 
        return new String[rankLength * suitLength];
    }
    
    public void displayDeckOfCards(String[] cards) {
        System.out.println("Original Deck:");
        for (int n = 0; n < cards.length; n++) {
            System.out.println(n + ": " + cards[n]);
        }
        System.out.println();
    }
    
    // Modified shuffle method to return the shuffled deck
    public String[] shuffleDeck(String[] cards) {
        // Create array for shuffled deck
        String[] shuffledDeck = new String[cards.length];
        
        // Create copy of original deck to track used cards
        String[] tempDeck = new String[cards.length];
        System.arraycopy(cards, 0, tempDeck, 0, cards.length);
        
        // Select the card at that random position from the original deck
        for (int n = 0; n < cards.length; n++) {
            // Generate random index
            int randomIndex = (int)(Math.random() * cards.length);
            
            // Check if card already used
            while (tempDeck[randomIndex] == null) {
                // If position already used, move to next position
                randomIndex = (randomIndex + 1) % cards.length;
            }
            
            // Add card to shuffled deck
            shuffledDeck[n] = tempDeck[randomIndex];
            
            // Mark that position as used (-1) to avoid selecting it again
            tempDeck[randomIndex] = null;
        }
        
        return shuffledDeck;
    }
    
    public void displayShuffledDeck(String[] shuffledCards) {
        // code to display the shuffled deck
        System.out.println("Shuffled Deck:");
        for (int n = 0; n < shuffledCards.length; n++) {
            System.out.println(n + ": " + shuffledCards[n]);
        }
    }
}